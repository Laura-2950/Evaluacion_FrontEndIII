import { Component } from "react";
import Option from "./components/Option";
import Recordatorio from "./components/Recordatorio";
import data from "./components/data.json"
import swal from 'react-sweetalert2';





class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      arrayRespuestas: [],
      respuestaAnterior: "",
      swal: {}
    };

  };

  componentDidUpdate(prevState) {
    if (prevState.counter !== this.state.counter) {
      this.state.arrayRespuestas.push(this.state.respuestaAnterior);
    }
  }
  componentWillUnmount(prevState){
    if(prevState.counter>=7){
      this.setState({
        swal: {
            show: true,
            title: "Fin.",
            icon: "success",
            timer: "2000"
        }
    });
    }
  }

  handleClick=(e)=>{
    const id = e.target.id;

    if (this.state.counter >= 7) {
      alert('Fin.');
    } else if (id === 'A' && this.state.respuestaAnterior !== 'A') {
      this.setState({
        counter: this.state.counter + 1,
        respuestaAnterior: 'A',
      });
    } else if (id === 'A' && this.state.respuestaAnterior === 'A') {
      this.setState({
        counter: this.state.counter + 2,
      });
    } else if (id === 'B' && this.state.respuestaAnterior === 'A') {
      this.setState({
        counter: this.state.counter + 3,
        respuestaAnterior: 'B',
      });
    } else if (id === 'B') {
      this.setState({
        counter: this.state.counter + 2,
        respuestaAnterior: 'B',
      });
    }
  }
  
  render() {
    return (
      <div className="App">
        <div className="layout">
          <h1 className="historia">{data[this.state.counter].historia}</h1>
          <div className="opciones">
            <Option id= "A" textOption={data[this.state.counter].opciones.a} handleClick={(e)=>this.handleClick(e)} />
            <Option id= "B" textOption={data[this.state.counter].opciones.b} handleClick={this.handleClick}/>
          </div>
          <Recordatorio 
          seleccionAnterior={this.state.respuestaAnterior} 
          historial={this.state.arrayRespuestas.map((item, i)=><li key={i}>{item}</li>,data[this.state.counter].id)}/>
        </div>
      </div>
    );
  }
}

export default App;
